## ablauf plus
--------------

A state machine implemented in python. Uses states and transitions. Enhanced wiht a MVC layer. The controllers are inspired by BPMN.

## contact:
-----------
thorsten.butschke@googlemail.com